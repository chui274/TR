##################################################
#                                                # 
#         EFFICENCY NETWORK ANALYSER             #
#                                                #
#            by Fabio Manganiello                #
#                                                #
##################################################
#                                                #
#    � Copyright 2003. All right reserved        #
#                                                #
##################################################


INFO:
***************************************************
Web Site: http://www.fabiomanganiello.com/tesi.htm*
                                                  *
E-Mail: mail@fabiomanganiello.com                 *
                                                  *
Cell.: +39.320.07234773                           *
                                                  *
Fax.: +39.02.700519398                            *
***************************************************

---------------------------------------------------
|Required Matlab 5.3 Release 11                   |
---------------------------------------------------
|Start File: ena.m                                |
---------------------------------------------------
|If you have Windows XP, add the                  |
|matlab.exe.manifest file to the                  |
|<Matlab>\bin\ directory where <Matlab> is your   |
|install directory.                               |
---------------------------------------------------
 